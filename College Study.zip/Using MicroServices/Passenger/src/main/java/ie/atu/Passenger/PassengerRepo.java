package ie.atu.Passenger;

public interface PassengerRepo {
}
