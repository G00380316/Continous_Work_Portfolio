# Continous_Work_Project
Research, design and build a high-quality CICD pipeline to generate a java micro services-based application(Shopping Cart).
